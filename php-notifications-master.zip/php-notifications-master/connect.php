<?php 
//connect.php;
$con = mysqli_connect("localhost", "yvwxxxxgfz", "jxxx7xxCe", "yxxaajxxxz");
?>
