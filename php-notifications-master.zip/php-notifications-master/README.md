
[![Build Status](https://travis-ci.org/shahroznawaz/php-notifications.svg?branch=master)](https://travis-ci.org/shahroznawaz/php-notifications)