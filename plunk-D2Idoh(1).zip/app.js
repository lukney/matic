var app = angular.module('plunker', ['nvd3ChartDirectives']);

app.controller('MainCtrl', function($scope) {
  $scope.name = 'World';
  
        $scope.exampleDataPieChart0 = [
            { key: "One", y: 5 },
            { key: "Two", y: 2 },
            { key: "Three", y: 9 },
            { key: "Four", y: 7 },
            { key: "Five", y: 4 },
            { key: "Six", y: 3 },
            { key: "Seven", y: 9 }
        ];  
        
        $scope.exampleDataPieChart1 = [
            { key: "One", y: 5 },
            { key: "Two", y: 2 },
            { key: "Three", y: 9 },
            { key: "Four", y: 7 },
            { key: "Five", y: 4 },
            { key: "Six", y: 3 },
            { key: "Seven", y: 9 }
        ];  
        
    $scope.exampleDataPieChart = [
      $scope.exampleDataPieChart0,
      $scope.exampleDataPieChart1
    ];
        
        $scope.xFunction = function () {
            return function (d) {
                return d.key;
            };
        };

        $scope.yFunction = function(){
            return function(d){
                return d.y;
            };
        }
});
